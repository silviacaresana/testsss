VerificheLab — pacchetto di esportazione
=======================================

Verifica: verifica-matematica-1-scientifico-2026-11-12-verifica-dimostrativa-funzioni-e-problemi-1-scie-vA
Motore LaTeX configurato: tectonic

Contenuto del pacchetto:
  - verifica (.tex + .pdf): consegna da stampare per gli studenti
  - soluzioni (.tex + .pdf): soluzioni svolte con criteri di punteggio
  - griglia (.tex + .pdf): indicatori, descrittori, conversione in decimi
  - verifica.json: dati strutturati per modifiche e rigenerazioni
  - README.txt: questo file

Compilazione con Tectonic:
  tectonic "verifica-matematica-1-scientifico-2026-11-12-verifica-dimostrativa-funzioni-e-problemi-1-scie-vA.tex"
  tectonic "soluzioni-matematica-1-scientifico-2026-11-12-verifica-dimostrativa-funzioni-e-problemi-1-scie-vA.tex"
  tectonic "griglia-matematica-1-scientifico-2026-11-12-verifica-dimostrativa-funzioni-e-problemi-1-scie-vA.tex"

Compilazione con pdflatex (due passate):
  pdflatex -interaction=nonstopmode "verifica-matematica-1-scientifico-2026-11-12-verifica-dimostrativa-funzioni-e-problemi-1-scie-vA.tex"
  pdflatex -interaction=nonstopmode "verifica-matematica-1-scientifico-2026-11-12-verifica-dimostrativa-funzioni-e-problemi-1-scie-vA.tex"

I file .tex sono autonomi: non richiedono immagini esterne né file di supporto.
Se un PDF manca nel pacchetto, apri il relativo .tex e controlla il log di compilazione.

Nessun dato di studenti è contenuto in questo pacchetto.

Esito compilazione:
  - verifica-matematica-1-scientifico-2026-11-12-verifica-dimostrativa-funzioni-e-problemi-1-scie-vA: PDF generato
  - soluzioni-matematica-1-scientifico-2026-11-12-verifica-dimostrativa-funzioni-e-problemi-1-scie-vA: PDF generato
  - griglia-matematica-1-scientifico-2026-11-12-verifica-dimostrativa-funzioni-e-problemi-1-scie-vA: PDF generato
